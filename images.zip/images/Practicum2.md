

```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from scipy.stats import norm
from sklearn.preprocessing import StandardScaler
from scipy import stats
import warnings
from sklearn.linear_model import LinearRegression
import scipy, scipy.stats
import statsmodels.formula.api as sm
from sklearn import linear_model
warnings.filterwarnings('ignore')
%matplotlib inline
```


```python
# Load spreadsheet
xl = pd.ExcelFile('dataset_homemade.xlsx')

# Load a sheet into a DataFrame by name: df1
df = xl.parse('Sheet2')
```


```python
df.tail()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>year</th>
      <th>gdp_nominal - US$MM</th>
      <th>gdp_per capita (usd)</th>
      <th>population</th>
      <th>host_y</th>
      <th>host_n</th>
      <th>Index of Economic Freedom</th>
      <th>no_of_internet_users</th>
      <th>Gender gap index</th>
      <th>number_sports_schools</th>
      <th>Sports_budget- millions</th>
      <th>Sports trainees</th>
      <th>Rank</th>
      <th>Olympics</th>
      <th>GOLD</th>
      <th>SILVER</th>
      <th>BRONZE</th>
      <th>total_No_of_medals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>100</th>
      <td>CRO</td>
      <td>2000</td>
      <td>21774.0</td>
      <td>10582.668170</td>
      <td>4505533</td>
      <td>0</td>
      <td>1</td>
      <td>NaN</td>
      <td>3063044</td>
      <td>714.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Summer</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>101</th>
      <td>CUB</td>
      <td>2000</td>
      <td>NaN</td>
      <td>6115.593942</td>
      <td>11104313</td>
      <td>0</td>
      <td>1</td>
      <td>NaN</td>
      <td>4449238</td>
      <td>716.9</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Summer</td>
      <td>11</td>
      <td>11</td>
      <td>7</td>
      <td>29</td>
    </tr>
    <tr>
      <th>102</th>
      <td>NZL</td>
      <td>2000</td>
      <td>54138.0</td>
      <td>21895.155980</td>
      <td>3858032</td>
      <td>0</td>
      <td>1</td>
      <td>NaN</td>
      <td>4123439</td>
      <td>751.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Summer</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>4</td>
    </tr>
    <tr>
      <th>103</th>
      <td>CAN</td>
      <td>2000</td>
      <td>742319.0</td>
      <td>32448.607640</td>
      <td>30667365</td>
      <td>0</td>
      <td>1</td>
      <td>NaN</td>
      <td>32602776</td>
      <td>716.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Summer</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>14</td>
    </tr>
    <tr>
      <th>104</th>
      <td>IND</td>
      <td>2000</td>
      <td>476636.0</td>
      <td>1648.208780</td>
      <td>1053898107</td>
      <td>0</td>
      <td>1</td>
      <td>NaN</td>
      <td>500292635</td>
      <td>601.1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Summer</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.columns
```




    Index(['country', 'year', 'gdp_nominal - US$MM', 'gdp_per capita (usd)',
           'population', 'host_y', 'host_n', 'Index of Economic Freedom',
           'no_of_internet_users', 'Gender gap index', 'number_sports_schools',
           'Sports_budget- millions', 'Sports trainees', 'Rank', 'Olympics',
           'GOLD', 'SILVER', 'BRONZE', 'total_No_of_medals'],
          dtype='object')




```python
df.shape
```




    (105, 19)




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 105 entries, 0 to 104
    Data columns (total 19 columns):
    country                      105 non-null object
    year                         105 non-null int64
    gdp_nominal - US$MM          102 non-null float64
    gdp_per capita (usd)         104 non-null float64
    population                   105 non-null int64
    host_y                       105 non-null int64
    host_n                       105 non-null int64
    Index of Economic Freedom    63 non-null float64
    no_of_internet_users         105 non-null int64
    Gender gap index             105 non-null float64
    number_sports_schools        0 non-null float64
    Sports_budget- millions      3 non-null float64
    Sports trainees              0 non-null float64
    Rank                         20 non-null float64
    Olympics                     105 non-null object
    GOLD                         105 non-null int64
    SILVER                       105 non-null int64
    BRONZE                       105 non-null int64
    total_No_of_medals           105 non-null int64
    dtypes: float64(8), int64(9), object(2)
    memory usage: 15.7+ KB
    


```python
##columns dropped
df_new = df.iloc[:,np.r_[0:10,14:19]]
```


```python
df_new.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>year</th>
      <th>gdp_nominal - US$MM</th>
      <th>gdp_per capita (usd)</th>
      <th>population</th>
      <th>host_y</th>
      <th>host_n</th>
      <th>Index of Economic Freedom</th>
      <th>no_of_internet_users</th>
      <th>Gender gap index</th>
      <th>Olympics</th>
      <th>GOLD</th>
      <th>SILVER</th>
      <th>BRONZE</th>
      <th>total_No_of_medals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>USA</td>
      <td>2016</td>
      <td>18624475.0</td>
      <td>59495.0</td>
      <td>322179605</td>
      <td>0</td>
      <td>1</td>
      <td>75.4</td>
      <td>245436423</td>
      <td>722.0</td>
      <td>Summer</td>
      <td>46</td>
      <td>37</td>
      <td>38</td>
      <td>121</td>
    </tr>
    <tr>
      <th>1</th>
      <td>GBR</td>
      <td>2016</td>
      <td>2624529.0</td>
      <td>43620.0</td>
      <td>65788574</td>
      <td>0</td>
      <td>1</td>
      <td>76.4</td>
      <td>62354410</td>
      <td>752.0</td>
      <td>Summer</td>
      <td>27</td>
      <td>23</td>
      <td>17</td>
      <td>67</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CHN</td>
      <td>2016</td>
      <td>11218281.0</td>
      <td>16624.0</td>
      <td>1403500365</td>
      <td>0</td>
      <td>1</td>
      <td>52.0</td>
      <td>746662194</td>
      <td>676.0</td>
      <td>Summer</td>
      <td>26</td>
      <td>18</td>
      <td>26</td>
      <td>70</td>
    </tr>
    <tr>
      <th>3</th>
      <td>RUS</td>
      <td>2016</td>
      <td>1527469.0</td>
      <td>27890.0</td>
      <td>146864513</td>
      <td>0</td>
      <td>1</td>
      <td>50.6</td>
      <td>110003284</td>
      <td>691.0</td>
      <td>Summer</td>
      <td>19</td>
      <td>17</td>
      <td>19</td>
      <td>55</td>
    </tr>
    <tr>
      <th>4</th>
      <td>GER</td>
      <td>2016</td>
      <td>3684816.0</td>
      <td>50206.0</td>
      <td>81914672</td>
      <td>0</td>
      <td>1</td>
      <td>74.4</td>
      <td>73436503</td>
      <td>766.0</td>
      <td>Summer</td>
      <td>17</td>
      <td>10</td>
      <td>15</td>
      <td>42</td>
    </tr>
  </tbody>
</table>
</div>




```python
#correlation matrix
corrmat = df_new.corr()
f, ax = plt.subplots(figsize=(12, 9))
sns.heatmap(corrmat, vmax=.9);
```


![png](output_8_0.png)



```python
corr=df_new.corr()["total_No_of_medals"]
corr
```




    year                         0.032971
    gdp_nominal - US$MM          0.740916
    gdp_per capita (usd)         0.358122
    population                   0.249202
    host_y                       0.212756
    host_n                      -0.212756
    Index of Economic Freedom    0.108904
    no_of_internet_users         0.392146
    Gender gap index             0.100406
    GOLD                         0.959320
    SILVER                       0.952456
    BRONZE                       0.947980
    total_No_of_medals           1.000000
    Name: total_No_of_medals, dtype: float64




```python
#Some data transformations
##Right Skewed
#histogram and normal probability plot
sns.distplot(df_new['total_No_of_medals'], fit=norm);
fig = plt.figure()
res = stats.probplot(df_new['total_No_of_medals'], plot=plt)
```


![png](output_10_0.png)



![png](output_10_1.png)



```python
sns.jointplot(df_new['total_No_of_medals'],df_new['gdp_nominal - US$MM'],color='gold');
```


![png](output_11_0.png)



```python
from sklearn.linear_model import LinearRegression
import scipy, scipy.stats
import statsmodels.formula.api as sm
```


```python
null_counts = df_new.isnull().sum()
null_counts[null_counts > 0].sort_values
```




    <bound method Series.sort_values of gdp_nominal - US$MM           3
    gdp_per capita (usd)          1
    Index of Economic Freedom    42
    dtype: int64>




```python
#Treating Missing Values
df_new['gdp_nominal - US$MM'].fillna(df_new['gdp_nominal - US$MM'].median(), inplace=True)
```


```python
#Treating Missing Values
df_new['gdp_per capita (usd)'].fillna(df_new['gdp_per capita (usd)'].median(), inplace=True)
```


```python
sns.distplot(df_new['gdp_per capita (usd)'], fit=norm);
fig = plt.figure()
res = stats.probplot(df_new['gdp_per capita (usd)'], plot=plt)
```


![png](output_16_0.png)



![png](output_16_1.png)



```python
sns.distplot(df_new['gdp_nominal - US$MM'], fit=norm);
fig = plt.figure()
res = stats.probplot(df_new['gdp_nominal - US$MM'], plot=plt)
```


![png](output_17_0.png)



![png](output_17_1.png)



```python
sns.distplot(df_new['population'], fit=norm);
fig = plt.figure()
res = stats.probplot(df_new['population'], plot=plt)
```


![png](output_18_0.png)



![png](output_18_1.png)



```python
sns.distplot(df_new['no_of_internet_users'], fit=norm);
fig = plt.figure()
res = stats.probplot(df_new['no_of_internet_users'], plot=plt)
```


![png](output_19_0.png)



![png](output_19_1.png)



```python
plt.scatter(df_new["no_of_internet_users"],df_new.total_No_of_medals, color='red')
plt.title("Scatter plot between internet users and number of models")
```




    <matplotlib.text.Text at 0x1735a860>




![png](output_20_1.png)



```python
plt.scatter(df_new["population"],df_new.total_No_of_medals, color='red')
plt.title("Scatter plot between population and number of models")
```




    <matplotlib.text.Text at 0x1729c860>




![png](output_21_1.png)



```python
plt.scatter(df_new["gdp_nominal - US$MM"],df_new.total_No_of_medals, color='red')
plt.title("Scatter plot between gdp_nominal - US$MM and number of models")
```




    <matplotlib.text.Text at 0x17306b70>




![png](output_22_1.png)



```python
plt.scatter(df_new["gdp_per capita (usd)"],df_new.total_No_of_medals, color='red')
plt.title("Scatter plot between gdp_per capita (usd) and number of models")
```




    <matplotlib.text.Text at 0x16931668>




![png](output_23_1.png)



```python
plt.scatter(df_new["Gender gap index"],df_new.total_No_of_medals, color='red')
plt.title("total_no_of_medals")
```




    <matplotlib.text.Text at 0x16a6d898>




![png](output_24_1.png)



```python
plt.scatter(df_new["Index of Economic Freedom"],df_new.total_No_of_medals, color='red')
plt.title("total_no_of_medals")
```




    <matplotlib.text.Text at 0x17368b70>




![png](output_25_1.png)



```python
X = df_new[['no_of_internet_users','population','gdp_nominal - US$MM','gdp_per capita (usd)']] 
 
```


```python
Y = df_new.iloc[:,-1]
```


```python
###multiple regression
```


```python
from sklearn import linear_model
from sklearn.linear_model import LinearRegression
import scipy, scipy.stats
import statsmodels.formula.api as sm
```


```python
df_new.shape
```




    (105, 15)




```python
result = sm.OLS(Y,X).fit()
result.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>    <td>total_No_of_medals</td> <th>  R-squared:         </th> <td>   0.852</td>
</tr>
<tr>
  <th>Model:</th>                    <td>OLS</td>        <th>  Adj. R-squared:    </th> <td>   0.846</td>
</tr>
<tr>
  <th>Method:</th>              <td>Least Squares</td>   <th>  F-statistic:       </th> <td>   145.6</td>
</tr>
<tr>
  <th>Date:</th>              <td>Sat, 22 Sep 2018</td>  <th>  Prob (F-statistic):</th> <td>5.20e-41</td>
</tr>
<tr>
  <th>Time:</th>                  <td>11:52:02</td>      <th>  Log-Likelihood:    </th> <td> -440.06</td>
</tr>
<tr>
  <th>No. Observations:</th>       <td>   105</td>       <th>  AIC:               </th> <td>   888.1</td>
</tr>
<tr>
  <th>Df Residuals:</th>           <td>   101</td>       <th>  BIC:               </th> <td>   898.7</td>
</tr>
<tr>
  <th>Df Model:</th>               <td>     4</td>       <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>       <td>nonrobust</td>     <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
            <td></td>              <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>no_of_internet_users</th> <td> 3.412e-07</td> <td> 5.23e-08</td> <td>    6.523</td> <td> 0.000</td> <td> 2.37e-07</td> <td> 4.45e-07</td>
</tr>
<tr>
  <th>population</th>           <td>-1.452e-07</td> <td> 2.55e-08</td> <td>   -5.705</td> <td> 0.000</td> <td>-1.96e-07</td> <td>-9.47e-08</td>
</tr>
<tr>
  <th>gdp_nominal - US$MM</th>  <td> 2.488e-06</td> <td> 6.84e-07</td> <td>    3.636</td> <td> 0.000</td> <td> 1.13e-06</td> <td> 3.85e-06</td>
</tr>
<tr>
  <th>gdp_per capita (usd)</th> <td>    0.0006</td> <td> 8.09e-05</td> <td>    7.296</td> <td> 0.000</td> <td>    0.000</td> <td>    0.001</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>35.763</td> <th>  Durbin-Watson:     </th> <td>   1.898</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td>  83.405</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.284</td> <th>  Prob(JB):          </th> <td>7.74e-19</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 6.531</td> <th>  Cond. No.          </th> <td>2.30e+04</td>
</tr>
</table>




```python
df_new.columns
```




    Index(['country', 'year', 'gdp_nominal - US$MM', 'gdp_per capita (usd)',
           'population', 'host_y', 'host_n', 'Index of Economic Freedom',
           'no_of_internet_users', 'Gender gap index', 'Olympics', 'GOLD',
           'SILVER', 'BRONZE', 'total_No_of_medals'],
          dtype='object')




```python
df_new.columns
df_1 = df_new.iloc[:,np.r_[2:7,8:10]].values

```


```python
###Backward elimination approach to make optimal model
X1 = np.append(arr = np.ones((105,1)).astype(int), values = df_1, axis = 1)
```


```python
x_1 = X1[:,[0,1,2,3,4,5,6,7]]
```


```python
x = df_new[['no_of_internet_users','population','gdp_nominal - US$MM','host_n','Gender gap index']].values
y = df_new.iloc[:,-1].values
```


```python
corr = np.corrcoef(x,rowvar=0)
corr
```




    array([[ 1.        ,  0.97802742,  0.40880026, -0.14428339, -0.34515587],
           [ 0.97802742,  1.        ,  0.29737937, -0.12424288, -0.37060942],
           [ 0.40880026,  0.29737937,  1.        , -0.01578514,  0.05378809],
           [-0.14428339, -0.12424288, -0.01578514,  1.        , -0.04579491],
           [-0.34515587, -0.37060942,  0.05378809, -0.04579491,  1.        ]])




```python
w,v = np.linalg.eig(corr)
w
```




    array([2.35954303, 0.01443785, 0.56020941, 1.08221582, 0.98359388])




```python
v[:,3]
v[:,4]
```




    array([ 0.01360174, -0.03346345,  0.51814854,  0.83756998,  0.16939248])




```python
reg_1 = sm.OLS(y,x_1).fit()
reg_1.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>            <td>y</td>        <th>  R-squared:         </th> <td>   0.714</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.696</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   40.74</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Sep 2018</td> <th>  Prob (F-statistic):</th> <td>1.57e-24</td>
</tr>
<tr>
  <th>Time:</th>                 <td>11:52:36</td>     <th>  Log-Likelihood:    </th> <td> -429.22</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>   105</td>      <th>  AIC:               </th> <td>   872.4</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>    98</td>      <th>  BIC:               </th> <td>   891.0</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     6</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
    <td></td>       <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th> <td>   -4.8578</td> <td>   18.519</td> <td>   -0.262</td> <td> 0.794</td> <td>  -41.609</td> <td>   31.893</td>
</tr>
<tr>
  <th>x1</th>    <td> 3.492e-06</td> <td> 6.65e-07</td> <td>    5.248</td> <td> 0.000</td> <td> 2.17e-06</td> <td> 4.81e-06</td>
</tr>
<tr>
  <th>x2</th>    <td> 7.761e-05</td> <td>    0.000</td> <td>    0.524</td> <td> 0.601</td> <td>   -0.000</td> <td>    0.000</td>
</tr>
<tr>
  <th>x3</th>    <td>-1.422e-07</td> <td> 2.35e-08</td> <td>   -6.047</td> <td> 0.000</td> <td>-1.89e-07</td> <td>-9.55e-08</td>
</tr>
<tr>
  <th>x4</th>    <td>    7.3376</td> <td>   10.885</td> <td>    0.674</td> <td> 0.502</td> <td>  -14.264</td> <td>   28.939</td>
</tr>
<tr>
  <th>x5</th>    <td>  -12.1954</td> <td>    9.139</td> <td>   -1.334</td> <td> 0.185</td> <td>  -30.331</td> <td>    5.940</td>
</tr>
<tr>
  <th>x6</th>    <td> 3.108e-07</td> <td> 4.87e-08</td> <td>    6.386</td> <td> 0.000</td> <td> 2.14e-07</td> <td> 4.07e-07</td>
</tr>
<tr>
  <th>x7</th>    <td>    0.0442</td> <td>    0.040</td> <td>    1.112</td> <td> 0.269</td> <td>   -0.035</td> <td>    0.123</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>42.692</td> <th>  Durbin-Watson:     </th> <td>   1.815</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td> 124.943</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.437</td> <th>  Prob(JB):          </th> <td>7.40e-28</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 7.506</td> <th>  Cond. No.          </th> <td>2.92e+22</td>
</tr>
</table>




```python
#second model
x_2 = X1[:,[1,2,3,4,5,6,7]]
reg_2 = sm.OLS(y,x_2).fit()
reg_2.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>            <td>y</td>        <th>  R-squared:         </th> <td>   0.714</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.696</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   40.74</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Sep 2018</td> <th>  Prob (F-statistic):</th> <td>1.57e-24</td>
</tr>
<tr>
  <th>Time:</th>                 <td>11:52:43</td>     <th>  Log-Likelihood:    </th> <td> -429.22</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>   105</td>      <th>  AIC:               </th> <td>   872.4</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>    98</td>      <th>  BIC:               </th> <td>   891.0</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     6</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td> 3.492e-06</td> <td> 6.65e-07</td> <td>    5.248</td> <td> 0.000</td> <td> 2.17e-06</td> <td> 4.81e-06</td>
</tr>
<tr>
  <th>x2</th> <td> 7.761e-05</td> <td>    0.000</td> <td>    0.524</td> <td> 0.601</td> <td>   -0.000</td> <td>    0.000</td>
</tr>
<tr>
  <th>x3</th> <td>-1.422e-07</td> <td> 2.35e-08</td> <td>   -6.047</td> <td> 0.000</td> <td>-1.89e-07</td> <td>-9.55e-08</td>
</tr>
<tr>
  <th>x4</th> <td>    2.4798</td> <td>   28.972</td> <td>    0.086</td> <td> 0.932</td> <td>  -55.015</td> <td>   59.975</td>
</tr>
<tr>
  <th>x5</th> <td>  -17.0532</td> <td>   27.101</td> <td>   -0.629</td> <td> 0.531</td> <td>  -70.835</td> <td>   36.728</td>
</tr>
<tr>
  <th>x6</th> <td> 3.108e-07</td> <td> 4.87e-08</td> <td>    6.386</td> <td> 0.000</td> <td> 2.14e-07</td> <td> 4.07e-07</td>
</tr>
<tr>
  <th>x7</th> <td>    0.0442</td> <td>    0.040</td> <td>    1.112</td> <td> 0.269</td> <td>   -0.035</td> <td>    0.123</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>42.692</td> <th>  Durbin-Watson:     </th> <td>   1.815</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td> 124.943</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.437</td> <th>  Prob(JB):          </th> <td>7.40e-28</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 7.506</td> <th>  Cond. No.          </th> <td>1.22e+10</td>
</tr>
</table>




```python
#third model
x_3 = X1[:,[1,2,3,5,6,7]]
reg_3 = sm.OLS(y,x_3).fit()
reg_3.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>            <td>y</td>        <th>  R-squared:         </th> <td>   0.880</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.872</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   120.7</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Sep 2018</td> <th>  Prob (F-statistic):</th> <td>2.93e-43</td>
</tr>
<tr>
  <th>Time:</th>                 <td>11:52:47</td>     <th>  Log-Likelihood:    </th> <td> -429.22</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>   105</td>      <th>  AIC:               </th> <td>   870.4</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>    99</td>      <th>  BIC:               </th> <td>   886.4</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     6</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td> 3.489e-06</td> <td> 6.61e-07</td> <td>    5.277</td> <td> 0.000</td> <td> 2.18e-06</td> <td>  4.8e-06</td>
</tr>
<tr>
  <th>x2</th> <td> 7.489e-05</td> <td>    0.000</td> <td>    0.521</td> <td> 0.604</td> <td>   -0.000</td> <td>    0.000</td>
</tr>
<tr>
  <th>x3</th> <td>-1.422e-07</td> <td> 2.34e-08</td> <td>   -6.083</td> <td> 0.000</td> <td>-1.89e-07</td> <td>-9.58e-08</td>
</tr>
<tr>
  <th>x4</th> <td>  -19.2879</td> <td>    7.232</td> <td>   -2.667</td> <td> 0.009</td> <td>  -33.638</td> <td>   -4.938</td>
</tr>
<tr>
  <th>x5</th> <td> 3.112e-07</td> <td> 4.82e-08</td> <td>    6.459</td> <td> 0.000</td> <td> 2.16e-07</td> <td> 4.07e-07</td>
</tr>
<tr>
  <th>x6</th> <td>    0.0474</td> <td>    0.011</td> <td>    4.128</td> <td> 0.000</td> <td>    0.025</td> <td>    0.070</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>42.752</td> <th>  Durbin-Watson:     </th> <td>   1.816</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td> 124.691</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.441</td> <th>  Prob(JB):          </th> <td>8.39e-28</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 7.494</td> <th>  Cond. No.          </th> <td>2.26e+09</td>
</tr>
</table>




```python
#fourth model
x_4 = X1[:,[1,3,5,6,7]]
reg_4 = sm.OLS(y,x_4).fit()
reg_4.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>            <td>y</td>        <th>  R-squared:         </th> <td>   0.879</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.873</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   145.9</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Sep 2018</td> <th>  Prob (F-statistic):</th> <td>2.63e-44</td>
</tr>
<tr>
  <th>Time:</th>                 <td>11:52:59</td>     <th>  Log-Likelihood:    </th> <td> -429.37</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>   105</td>      <th>  AIC:               </th> <td>   868.7</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   100</td>      <th>  BIC:               </th> <td>   882.0</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     5</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td> 3.662e-06</td> <td> 5.69e-07</td> <td>    6.433</td> <td> 0.000</td> <td> 2.53e-06</td> <td> 4.79e-06</td>
</tr>
<tr>
  <th>x2</th> <td>-1.438e-07</td> <td> 2.31e-08</td> <td>   -6.223</td> <td> 0.000</td> <td> -1.9e-07</td> <td>-9.79e-08</td>
</tr>
<tr>
  <th>x3</th> <td>  -19.5767</td> <td>    7.185</td> <td>   -2.725</td> <td> 0.008</td> <td>  -33.831</td> <td>   -5.323</td>
</tr>
<tr>
  <th>x4</th> <td> 3.116e-07</td> <td>  4.8e-08</td> <td>    6.491</td> <td> 0.000</td> <td> 2.16e-07</td> <td> 4.07e-07</td>
</tr>
<tr>
  <th>x5</th> <td>    0.0501</td> <td>    0.010</td> <td>    4.883</td> <td> 0.000</td> <td>    0.030</td> <td>    0.070</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>40.730</td> <th>  Durbin-Watson:     </th> <td>   1.800</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td> 112.745</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.389</td> <th>  Prob(JB):          </th> <td>3.29e-25</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 7.249</td> <th>  Cond. No.          </th> <td>2.25e+09</td>
</tr>
</table>




```python
###splitting the data into trian and test set.
from sklearn.cross_validation import train_test_split
from sklearn import model_selection

```


```python
x = df_new[['gdp_nominal - US$MM','population','host_n','no_of_internet_users','Gender gap index']].values
y = df_new.iloc[:,-1].values
```


```python
x = df_new[['gdp_nominal - US$MM','population','host_n','no_of_internet_users','Gender gap index']].values
```


```python
import statsmodels.api as sm
```


```python
X_train,X_test,y_train,y_test = train_test_split(x,y,test_size = 0.25, random_state = 0)
```


```python
X_test.shape
```




    (27, 5)




```python
result = sm.OLS(y_train,X_train).fit()
result.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>            <td>y</td>        <th>  R-squared:         </th> <td>   0.905</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.899</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   139.1</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Sep 2018</td> <th>  Prob (F-statistic):</th> <td>7.22e-36</td>
</tr>
<tr>
  <th>Time:</th>                 <td>11:54:37</td>     <th>  Log-Likelihood:    </th> <td> -310.28</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>    78</td>      <th>  AIC:               </th> <td>   630.6</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>    73</td>      <th>  BIC:               </th> <td>   642.3</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     5</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td>  4.08e-06</td> <td> 5.35e-07</td> <td>    7.632</td> <td> 0.000</td> <td> 3.01e-06</td> <td> 5.15e-06</td>
</tr>
<tr>
  <th>x2</th> <td>-1.301e-07</td> <td> 2.26e-08</td> <td>   -5.762</td> <td> 0.000</td> <td>-1.75e-07</td> <td>-8.51e-08</td>
</tr>
<tr>
  <th>x3</th> <td>  -17.6383</td> <td>    7.595</td> <td>   -2.322</td> <td> 0.023</td> <td>  -32.775</td> <td>   -2.501</td>
</tr>
<tr>
  <th>x4</th> <td> 2.856e-07</td> <td> 4.61e-08</td> <td>    6.193</td> <td> 0.000</td> <td> 1.94e-07</td> <td> 3.78e-07</td>
</tr>
<tr>
  <th>x5</th> <td>    0.0457</td> <td>    0.011</td> <td>    4.207</td> <td> 0.000</td> <td>    0.024</td> <td>    0.067</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>36.793</td> <th>  Durbin-Watson:     </th> <td>   2.015</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td> 138.622</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.366</td> <th>  Prob(JB):          </th> <td>7.92e-31</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 8.932</td> <th>  Cond. No.          </th> <td>2.34e+09</td>
</tr>
</table>




```python
y_pred = result.predict(X_test)
```


```python
y_pred  ##predicted values
```




    array([54.60144307, 26.23817823, 89.63062736,  2.95816507, 32.82324095,
           35.60975127, 14.87075378, 15.36116791, 10.99466206, 34.3659528 ,
           28.50454365, 23.64124509, 23.01634266, 26.05114388, 25.11038312,
           25.13126065, 54.36025795, 35.93519398, 33.54452673, 25.77112731,
           37.65755588, 48.57955444, 32.45206203, 14.25833717, 24.4051325 ,
           26.43641562, 34.77945982])




```python
y_test
```




    array([38, 20, 70,  3, 28, 35, 10,  2, 16, 60, 90, 11, 46, 17, 21, 35, 65,
           70, 17, 28, 51, 37, 55, 17, 12, 10, 42], dtype=int64)




```python
plt.scatter(result.predict(X_test),y_test)
plt.show()
```


![png](output_54_0.png)



```python
##mean square error
np.mean((result.predict(X_test) - y_test)**2) 
```


```python
##QQ plot of errors
fig = plt.figure()
res = stats.probplot(y_test - y_pred, plot=plt)
```


![png](output_56_0.png)



```python
plt.plot(result.predict(X_test), y_test - result.predict(X_test), 'bo')
plt.axhline(y=0, color='black')
plt.title('Linear')
plt.xlabel('predicted values')
plt.ylabel('residuals')
plt.show()
```


![png](output_57_0.png)



```python
##cook's distance
influence = result.get_influence()

(cook, p) = influence.cooks_distance
plt.stem(np.arange(len(cook)), cook, markerfmt=",")
```




    <Container object of 3 artists>




![png](output_58_1.png)



```python
from statsmodels.graphics.regressionplots import *
plot_leverage_resid2(result)

```




![png](output_59_0.png)




![png](output_59_1.png)



```python
influence_plot(result)
```




![png](output_60_0.png)




![png](output_60_1.png)



```python
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from math import sqrt
rmse_ols_withoutscaling= sqrt(mean_squared_error(y_test, y_pred))
rmse_ols_withoutscaling
```




    18.38920002770533




```python
mean_squared_error(y_test, y_pred)
```




    338.16267765895765




```python
mean_absolute_error(y_test, y_pred)
```




    13.58217196028744




```python
#MAPE
y = np.mean(np.abs((y_test - y_pred) / y_test)) * 100
y
```




    67.33740754292982




```python

# fit a model
lm = linear_model.LinearRegression()

model1 = lm.fit(X_train, y_train)
predictions = lm.predict(X_test)
```


```python
model1.score(X_test, y_test)
```




    0.3524513413500523




```python

plt.scatter(y_test, predictions)
plt.xlabel("Actual Values")
plt.ylabel("Predictions")
```




    <matplotlib.text.Text at 0x18bf4a20>




![png](output_67_1.png)



```python

```


```python

df_new[df_new.dtypes[(df.dtypes=="float64")|(df.dtypes=="int64")].index.values].hist(figsize=[12,12])
```




    array([[<matplotlib.axes._subplots.AxesSubplot object at 0x0000000018E94AC8>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x000000001918A240>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x000000001910A198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000000019279940>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x00000000192DF128>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x00000000192DF160>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x00000000197DE390>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000000019817CC0>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x00000000198A2940>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x00000000198B4F28>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000000019973400>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x00000000192A5978>],
           [<matplotlib.axes._subplots.AxesSubplot object at 0x0000000018E31438>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x00000000199F35C0>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000000019A63198>,
            <matplotlib.axes._subplots.AxesSubplot object at 0x0000000019ABDC18>]],
          dtype=object)




![png](output_69_1.png)



```python
#uthaya
#Importing MinMaxScaler and initializing it
from sklearn.preprocessing import MinMaxScaler
minmax=MinMaxScaler()
#Scaling down both train and test data set
X_trainminmax=min_max.fit_transform(X_train)
X_testminmax=min_max.fit_transform(X_test)
```


```python
result1 = sm.OLS(y_train,X_trainminmax).fit()
result1.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>            <td>y</td>        <th>  R-squared:         </th> <td>   0.893</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.886</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   122.1</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Sep 2018</td> <th>  Prob (F-statistic):</th> <td>5.12e-34</td>
</tr>
<tr>
  <th>Time:</th>                 <td>12:06:37</td>     <th>  Log-Likelihood:    </th> <td> -314.85</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>    78</td>      <th>  AIC:               </th> <td>   639.7</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>    73</td>      <th>  BIC:               </th> <td>   651.5</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     5</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td>   71.7318</td> <td>   10.647</td> <td>    6.737</td> <td> 0.000</td> <td>   50.512</td> <td>   92.951</td>
</tr>
<tr>
  <th>x2</th> <td> -185.8023</td> <td>   32.167</td> <td>   -5.776</td> <td> 0.000</td> <td> -249.910</td> <td> -121.694</td>
</tr>
<tr>
  <th>x3</th> <td>    4.0793</td> <td>    3.892</td> <td>    1.048</td> <td> 0.298</td> <td>   -3.678</td> <td>   11.837</td>
</tr>
<tr>
  <th>x4</th> <td>  232.4739</td> <td>   35.989</td> <td>    6.460</td> <td> 0.000</td> <td>  160.748</td> <td>  304.200</td>
</tr>
<tr>
  <th>x5</th> <td>   17.7102</td> <td>    6.369</td> <td>    2.781</td> <td> 0.007</td> <td>    5.016</td> <td>   30.404</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>36.597</td> <th>  Durbin-Watson:     </th> <td>   1.851</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td>  98.328</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.537</td> <th>  Prob(JB):          </th> <td>4.45e-22</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 7.561</td> <th>  Cond. No.          </th> <td>    34.4</td>
</tr>
</table>




```python
y_pred1 = result1.predict(X_testminmax)
```


```python
y_pred1
```




    array([ 68.82467602,  32.02270817, 130.80288637,   9.66502042,
            41.22807628,  46.66458736,  15.46199248,  16.93689729,
             8.39308691,  41.45694414,  31.27807165,  28.66715309,
            28.15086501,  33.16804367,  26.48516022,  31.82245673,
            43.89956194,  43.8222004 ,  41.82390085,  32.89007597,
            48.99565913,  58.96728271,  38.32023855,  12.86361869,
            29.18196181,  27.89894803,  46.53416628])




```python
y_test
```




    array([38, 20, 70,  3, 28, 35, 10,  2, 16, 60, 90, 11, 46, 17, 21, 35, 65,
           70, 17, 28, 51, 37, 55, 17, 12, 10, 42], dtype=int64)




```python
from math import sqrt
rmse_ols = sqrt(mean_squared_error(y_test, y_pred1))
rmse_ols
```




    22.253664804011354




```python
##line plot
sns.kdeplot(y_pred1, label = 'Predictions')
sns.kdeplot(y_test,label = 'Vales')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1a1ba160>




![png](output_76_1.png)



```python
##gradient boosting regressor
from sklearn.ensemble import GradientBoostingRegressor

c = GradientBoostingRegressor()

c.fit(X_train,y_train)
```




    GradientBoostingRegressor(alpha=0.9, criterion='friedman_mse', init=None,
                 learning_rate=0.1, loss='ls', max_depth=3, max_features=None,
                 max_leaf_nodes=None, min_impurity_split=1e-07,
                 min_samples_leaf=1, min_samples_split=2,
                 min_weight_fraction_leaf=0.0, n_estimators=100,
                 presort='auto', random_state=None, subsample=1.0, verbose=0,
                 warm_start=False)




```python
pred = c.predict(X_test)
mae = np.mean(abs(pred - y_test))
```


```python
mae
```




    11.553307096107396




```python
from math import sqrt
rmse_GB = sqrt(mean_squared_error(y_test, pred))
rmse_GB
```




    15.870378513251822




```python
pred
```




    array([30.37322921, 23.20038308, 93.35850247, -0.32727455, 28.38373415,
           36.81914088,  6.95268583, 12.04646516,  9.58618783, 36.36280138,
           38.12632426, 20.01109248, 40.01432684, 19.53626986, 31.84835735,
           23.44301863, 39.89373027, 42.54087747, 25.34346499, 38.51444573,
           36.81914088, 29.06502374, 36.36280138, 13.24408643, 23.63657343,
           18.2986027 , 40.60078111])




```python
y_test
```




    array([38, 20, 70,  3, 28, 35, 10,  2, 16, 60, 90, 11, 46, 17, 21, 35, 65,
           70, 17, 28, 51, 37, 55, 17, 12, 10, 42], dtype=int64)




```python
plt.scatter(y_test, pred)
plt.xlabel("True Values")
plt.ylabel("Predictions")
```




    <matplotlib.text.Text at 0x19eea780>




![png](output_83_1.png)



```python
from sklearn.ensemble import RandomForestRegressor
```


```python
c = RandomForestRegressor(random_state = 30)
c.fit(X_train,y_train)
pred = c.predict(X_test)
mae = np.mean(abs(pred - y_test))
mean_squared_error(y_test, pred)
```




    380.0618518518518




```python
mae = np.mean(abs(pred - y_test))
mae
```




    14.381481481481481




```python
from math import sqrt
rmse_RF = sqrt(mean_squared_error(y_test, pred))
rmse_RF
```




    19.495175091592582




```python
##line plot
sns.kdeplot(pred, label = 'Predictions')
sns.kdeplot(y_test,label = 'Vales')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1cc24f98>




![png](output_88_1.png)



```python
from sklearn.neighbors import KNeighborsRegressor
c = KNeighborsRegressor(n_neighbors = 2)
```


```python
c.fit(X_train,y_train)
pred = c.predict(X_test)
mae = np.mean(abs(pred - y_test))
mean_squared_error(y_test, pred)
```




    100.38888888888889




```python
mae = np.mean(abs(pred - y_test))
mae
```




    7.444444444444445




```python
from math import sqrt
rmse_KNN = sqrt(mean_squared_error(y_test, pred))
rmse_KNN
```




    10.019425576792758




```python
G = pd.DataFrame({'RMSE': [rmse_KNN,rmse_RF,rmse_GB,rmse_ols,rmse_ols_withoutscaling,rmse_xgb],'model_name':['K-nearest Neighbors','Random Forest','Gradient Boosting','Ordinary LS','Ordinary LS without scaling','XGBoost']})
```


```python
ax = plt.subplot()
ax.set_title('Comparison of Models Accuracy')
G.groupby('model_name').mean()['RMSE'].plot(kind='bar',figsize=(10,8), ax = ax,color = ('green','red','green','green','green','green'))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1ee239e8>




![png](output_94_1.png)



```python
plt.scatter(y_test, pred)
plt.xlabel("True Values")
plt.ylabel("Predictions")
```




    <matplotlib.text.Text at 0x1b805cf8>




![png](output_95_1.png)



```python
##residuals - fitted values
residual = y_test - pred
plt.scatter(pred,residual)
```




    <matplotlib.collections.PathCollection at 0x1b964c50>




![png](output_96_1.png)



```python
figsize = (8,8)

r = pred - y_test
plt.hist(r,color = 'red', bins = 20,edgecolor = 'black')
plt.xlabel('Residuals')
plt.title('Dist of Residuals')
```




    <matplotlib.text.Text at 0x1a680f28>




![png](output_97_1.png)



```python
##line plot
sns.kdeplot(pred, label = 'Predictions')
sns.kdeplot(y_test,label = 'Vales')

```




    <matplotlib.axes._subplots.AxesSubplot at 0x1bca5588>




![png](output_98_1.png)



```python
###k-fold cross validation
from sklearn.model_selection import cross_val_score
efficiency = cross_val_score(estimator = c, X= X_train, y = y_train, cv = 10)
efficiency

```




    array([ 0.90308735,  0.40965325,  0.9327203 ,  0.569522  ,  0.9600856 ,
           -0.12679426,  0.9458242 ,  0.91388119,  0.4723171 ,  0.71271263])




```python
efficiency.mean()
```




    0.6693009346625299




```python
##Applying Grid search method#Optimization techniques
```


```python
from sklearn.model_selection import GridSearchCV
parameters = [{'algorithm': ['auto','ball_tree']# ‘kd_tree’, ‘brute’],
               ,'n_neighbors':[2,3,4,5],
               'leaf_size':[20,25,20,35],'p':[1,2],'n_jobs':[-1]}]
grid_s = GridSearchCV(estimator = c,param_grid = parameters,scoring = 'r2',cv = 10,n_jobs = -1)
grid_s = grid_s.fit(X_train,y_train)
best_param = grid_s.best_params_
```


```python
best_param
```




    {'algorithm': 'auto', 'leaf_size': 20, 'n_jobs': -1, 'n_neighbors': 2, 'p': 1}




```python
best_accuracy = grid_s.best_score_
best_accuracy
```




    0.6721860613751406




```python

```


```python
##Applying XGBOOST method
```


```python
from xgboost import XGBRegressor 
import xgboost as xgb
```


```python
model_xgb = XGBRegressor()
model_xgb.fit(X_train, y_train)
```




    XGBRegressor(base_score=0.5, booster='gbtree', colsample_bylevel=1,
           colsample_bytree=1, gamma=0, learning_rate=0.1, max_delta_step=0,
           max_depth=3, min_child_weight=1, missing=None, n_estimators=100,
           n_jobs=1, nthread=None, objective='reg:linear', random_state=0,
           reg_alpha=0, reg_lambda=1, scale_pos_weight=1, seed=None,
           silent=True, subsample=1)




```python
y_pred_xgb = model_xgb.predict(X_test)
```


```python
y_pred_xgb
```




    array([10.101154 ,  9.565032 , 24.341003 ,  1.1759995,  9.648361 ,
           12.906151 ,  2.3163729,  3.250154 ,  3.929835 , 18.69073  ,
           19.951208 ,  7.0283065,  9.843973 ,  6.037368 ,  9.004144 ,
            8.219137 , 12.1687975, 18.357227 ,  7.7765718, 13.613796 ,
           13.114792 , 11.923305 , 17.799566 ,  3.0716302, 11.236645 ,
            7.364332 , 11.404296 ], dtype=float32)




```python
y_test
```




    array([17,  8, 26,  2,  7, 13,  2,  1,  6, 23, 36,  5, 17,  6,  9, 12, 19,
           30,  9,  8, 19, 12, 19,  3,  3,  3, 14], dtype=int64)




```python
plt.scatter(y_pred_xgb,y_test-y_pred_xgb)

plt.xlabel("residuals")
plt.ylabel("fitted values")
```




    <matplotlib.text.Text at 0x169eae48>




![png](output_112_1.png)



```python
##line plot
sns.kdeplot(y_pred_xgb, label = 'Predictions')
sns.kdeplot(y_test,label = 'Vales')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x16a1c4e0>




![png](output_113_1.png)



```python
figsize = (8,8)
r = y_pred_xgb - y_test
plt.hist(r,color = 'red', bins = 20,edgecolor = 'black')
plt.xlabel('Residuals')
plt.title('Dist of Residuals')
```




    <matplotlib.text.Text at 0x1bef86a0>




![png](output_114_1.png)



```python
mae = np.mean(abs(y_pred_xgb - y_test))
mae
```




    3.6826813176826194




```python
from math import sqrt
rmse_xgb= sqrt(mean_squared_error(y_test, y_pred_xgb))
rmse_xgb
```




    5.307733160990386




```python
print(model_xgb.feature_importances_)

```

    [0.3577371  0.29284525 0.         0.07487521 0.27454242]
    


```python
xgb.plot_importance(model_xgb,height=0.9,title='Feature importance',importance_type='weight', grid=True,color = 'orange')

```




    <matplotlib.axes._subplots.AxesSubplot at 0x1e7fb358>




![png](output_118_1.png)



```python
df_pivot= df.pivot_table(index = "country",columns = "year",values = "total_No_of_medals",aggfunc = 'sum')
```


```python
f, ax = plt.subplots(figsize=(10, 8))
sns.heatmap(df_pivot, annot=True, fmt="d", linewidths=.5, ax=ax)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1ccd0358>




![png](output_120_1.png)



```python
##Prediction on test dataset which contain values of parameters for 2020 year.
```


```python

```


```python
# Load spreadsheet
xl = pd.ExcelFile('test_data_2020_olympics.xlsx')

# Load a sheet into a DataFrame by name: df1
df_test = xl.parse('Sheet1')
```


```python
df_test.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 21 entries, 0 to 20
    Data columns (total 14 columns):
    country                      21 non-null object
    year                         21 non-null int64
    gdp_nominal - US$MM          20 non-null float64
    gdp_per capita (usd)         0 non-null float64
    population                   21 non-null int64
    host_y                       21 non-null int64
    host_n                       21 non-null int64
    Index of Economic Freedom    0 non-null float64
    no_of_internet_users         21 non-null int64
    Gender gap index             21 non-null int64
    GOLD                         0 non-null float64
    SILVER                       0 non-null float64
    BRONZE                       0 non-null float64
    total_No_of_medals           0 non-null float64
    dtypes: float64(7), int64(6), object(1)
    memory usage: 2.4+ KB
    


```python
##prediction of gold medals
o_2020 = df_test.iloc[:,np.r_[2:3,4:5,6:7,8:10]]
null_counts = o_2020.isnull().sum()
null_counts[null_counts > 0].sort_values
```




    <bound method Series.sort_values of gdp_nominal - US$MM    1
    dtype: int64>




```python
#Treating Missing Values
df_test['gdp_nominal - US$MM'].fillna(df_test['gdp_nominal - US$MM'].median(), inplace=True)
```


```python
##prediction of gold medals on validation sample
from sklearn.neighbors import KNeighborsRegressor
c = KNeighborsRegressor(n_neighbors = 2)
```


```python
total_p =  df_test.iloc[:,np.r_[2:3,4:5,6:7,8:10]].values
```


```python
total_p
```




    array([[2.22357310e+07, 3.30846000e+08, 1.00000000e+00, 2.86942362e+08,
            7.18000000e+02],
           [3.12142100e+06, 6.61680000e+07, 1.00000000e+00, 6.30614190e+07,
            7.70000000e+02],
           [1.69520080e+07, 1.39047500e+09, 1.00000000e+00, 7.72000000e+08,
            6.74000000e+02],
           [1.78675500e+06, 1.41622000e+08, 1.00000000e+00, 1.09552842e+08,
            6.96000000e+02],
           [4.62862100e+06, 7.97860000e+07, 1.00000000e+00, 7.91275510e+07,
            7.78000000e+02],
           [5.49877700e+06, 1.24173000e+08, 0.00000000e+00, 1.18626672e+08,
            6.57000000e+02],
           [3.19615600e+06, 6.52340000e+07, 1.00000000e+00, 6.04216890e+07,
            7.78000000e+02],
           [1.86399700e+06, 5.08200000e+07, 1.00000000e+00, 4.73536490e+07,
            6.50000000e+02],
           [2.34024600e+06, 5.93280000e+07, 1.00000000e+00, 5.47982990e+07,
            6.92000000e+02],
           [1.66674300e+06, 2.53820000e+07, 1.00000000e+00, 2.17438030e+07,
            7.31000000e+02],
           [1.03915700e+06, 1.70590000e+07, 1.00000000e+00, 1.63838790e+07,
            7.37000000e+02],
           [1.83101000e+05, 9.60400000e+06, 1.00000000e+00, 8.58877600e+06,
            6.70000000e+02],
           [2.36286600e+06, 2.13914000e+08, 1.00000000e+00, 1.49057635e+08,
            6.84000000e+02],
           [1.66019700e+06, 4.58350000e+07, 1.00000000e+00, 4.29612300e+07,
            7.46000000e+02],
           [1.03462000e+05, 5.17240000e+07, 1.00000000e+00, 4.33294340e+07,
            6.94000000e+02],
           [1.65980000e+04, 2.81100000e+06, 1.00000000e+00, 1.58110000e+06,
            7.17000000e+02],
           [6.65530000e+04, 4.13000000e+06, 1.00000000e+00, 3.78783800e+06,
            7.11000000e+02],
           [1.94658150e+06, 1.12790000e+07, 1.00000000e+00, 3.69676500e+06,
            7.45000000e+02],
           [2.51177000e+05, 4.69200000e+06, 1.00000000e+00, 4.18452000e+06,
            7.91000000e+02],
           [2.02916600e+06, 3.72910000e+07, 1.00000000e+00, 3.30003810e+07,
            7.69000000e+02],
           [3.47705200e+06, 1.37562700e+09, 1.00000000e+00, 4.62124989e+08,
            6.69000000e+02]])




```python
c.fit(X_train,y_train)
pred_t = c.predict(total_p)

```


```python
pred_t
```




    array([112. ,  48.5,  95.5,  65. ,  43. ,  21.5,  51. ,  31. ,  35.5,
            39.5,  19.5,  16.5,  17.5,  29. ,  31. ,  11.5,   7. ,  21. ,
            15.5,  20. ,   4. ])




```python
##prediction of gold medals on validation sample
from sklearn.neighbors import KNeighborsRegressor
c = KNeighborsRegressor(n_neighbors = 2)
```


```python
y = df_new.iloc[:,11].values
```


```python
y
```




    array([46, 27, 26, 19, 17, 12, 10,  9,  8,  8,  8,  8,  7,  7,  6,  6,  5,
            5,  4,  4,  0, 46, 29, 38, 20, 11,  7, 11, 13,  8,  8,  6,  8,  3,
            4,  2,  4,  3,  5,  6,  2,  0, 36, 19, 48, 24, 16,  9, 11, 13,  8,
           14,  7,  3,  3,  5,  6,  5,  0,  3,  3,  3,  1, 36,  9, 32, 28, 13,
           16, 11,  9, 10, 17,  4,  8,  5,  3,  1,  2,  1,  9,  3,  3,  0, 37,
           11, 28, 32, 13,  5, 13,  8, 13, 16, 12,  8,  0,  3,  2,  0,  1, 11,
            1,  3,  0], dtype=int64)




```python
X_train,X_test,y_train,y_test = train_test_split(x,y,test_size = 0.25, random_state = 0)
```


```python
gold_model = c.fit(X_train,y_train)
pred_gold = c.predict(X_test)
mae = np.mean(abs(pred_gold - y_test))
mean_squared_error(y_test, pred_gold)
```




    24.203703703703702




```python
mae = np.mean(abs(pred_gold - y_test))
mae
```




    3.185185185185185




```python
from math import sqrt
rmse_KNN = sqrt(mean_squared_error(y_test, pred_gold))
rmse_KNN
```




    4.919725978517879




```python
pred_gold
```




    array([ 7. ,  2.5, 43. ,  0. , 11. , 11. ,  1.5,  0.5,  1.5, 22. , 22. ,
            4. , 16.5,  4.5, 13. , 12.5, 18. , 22. ,  5. ,  9. , 18. ,  7. ,
           22. ,  5.5,  2.5,  1.5, 11. ])




```python
y_test
```




    array([ 7,  3, 26,  1, 11, 11,  5,  1,  6, 24, 28,  3, 14,  7,  9,  8, 29,
           20,  3,  8, 19, 16, 19,  8,  3,  5, 10], dtype=int64)




```python
##prediction of gold medals for 2020 olypica using Test dataset
pred_gold = c.predict(total_p)
```


```python
pred_gold
```




    array([46. , 18. , 43. , 22. , 14. ,  7. , 19. , 13. , 12. , 12.5,  7. ,
            8. ,  5. ,  8.5, 13. ,  5. ,  3. ,  7. ,  5. ,  3. ,  0. ])




```python
##for silver medal
y = df_new.iloc[:,12].values
```


```python
X_train,X_test,y_train,y_test = train_test_split(x,y,test_size = 0.25, random_state = 0)
```


```python
c.fit(X_train,y_train)
pred_silver = c.predict(X_test)
mae = np.mean(abs(pred_silver - y_test))
mean_squared_error(y_test, pred_silver)
```




    19.5




```python
mae = np.mean(abs(pred_silver - y_test))
mae
```




    3.4444444444444446




```python
from math import sqrt
rmse_KNN = sqrt(mean_squared_error(y_test, pred_silver))
rmse_KNN
```




    4.415880433163924




```python
pred_silver
```




    array([ 7.5,  4. , 26.5,  1.5, 11.5, 10. ,  1.5,  2. ,  4. , 18. , 18. ,
           11. , 20.5, 10.5, 10. , 13.5, 16. , 18. ,  5. , 10. , 16. ,  7.5,
           18. ,  5.5,  4. ,  5. , 10. ])




```python
y_test
```




    array([14,  9, 18,  0, 10, 11,  3,  0,  4, 13, 26,  3, 15,  4,  3, 15, 17,
           20,  5, 12, 13,  9, 17,  6,  6,  2, 18], dtype=int64)




```python
pred_silver = c.predict(total_p)
```


```python
pred_silver
```




    array([32.5, 16. , 26.5, 18. , 15. ,  7.5, 17. , 10. , 11.5, 13.5,  6.5,
            3.5,  5. , 11. , 10. ,  4. ,  2. ,  5. ,  5.5,  4. ,  1.5])




```python
###prediction for bronze medals
```


```python
y = df_new.iloc[:,13].values
```


```python
X_train,X_test,y_train,y_test = train_test_split(x,y,test_size = 0.25, random_state = 0)
```


```python
c.fit(X_train,y_train)
pred_bronze = c.predict(X_test)
mae = np.mean(abs(pred_bronze - y_test))
mean_squared_error(y_test, pred_bronze)
```




    17.12962962962963




```python
mae = np.mean(abs(pred_bronze - y_test))
mae
```




    2.962962962962963




```python
from math import sqrt
rmse_KNN = sqrt(mean_squared_error(y_test, pred_bronze))
rmse_KNN
```




    4.138795673819817




```python
pred_bronze
```




    array([ 7. ,  9.5, 26. ,  2. , 11.5, 13. ,  2.5,  2.5,  4. , 25. , 25. ,
            4.5, 17. ,  3.5,  8. , 13.5, 14.5, 25. ,  7.5, 10.5, 14.5,  7. ,
           25. ,  2.5,  9.5,  7.5, 13. ])




```python
y_test
```




    array([17,  8, 26,  2,  7, 13,  2,  1,  6, 23, 36,  5, 17,  6,  9, 12, 19,
           30,  9,  8, 19, 12, 19,  3,  3,  3, 14], dtype=int64)




```python
pred_bronze = c.predict(total_p)
```


```python
pred_bronze
```




    array([33.5, 14.5, 26. , 25. , 14. ,  7. , 15. ,  8. , 12. , 13.5,  6. ,
            5. ,  7.5,  9.5,  8. ,  2.5,  2. ,  9. ,  5. , 13. ,  2.5])




```python
##Applying log transformation method
```


```python
df_new['log_transformed_gold'] = (df['GOLD']+1).apply(np.log)  # Get the log of the data
df_new['log_transformed_gold'].hist(figsize = (6,6),bins=40)
```


```python
df_new['log_transformed_silver'] = (df['SILVER']+1).apply(np.log)  # Get the log of the data
df_new['log_transformed_silver'].hist(figsize = (6,6),bins=40)
```


```python
df_new['log_transformed_bronze'] = (df['BRONZE']+1).apply(np.log)  # Get the log of the data
df_new['log_transformed_bronze'].hist(figsize = (6,6),bins=40)
```


```python
df_new['log_transformed_total'] = (df['total_No_of_medals']+1).apply(np.log)  # Get the log of the data
df_new['log_transformed_total'].hist(figsize = (6,6),bins=40)
```


```python
df_new['log_transformed_gdp_cap'] = (df['gdp_per capita (usd)']+1).apply(np.log)  # Get the log of the data
df_new['log_transformed_gdp_cap'].hist(figsize = (6,6),bins=40)
```


```python
df_new['log_transformed_pop'] = (df['population']+1).apply(np.log)  # Get the log of the data
df_new['log_transformed_pop'].hist(figsize = (6,6),bins=20)
```


```python
df_new['log_transformed_int'] = (df['no_of_internet_users']+1).apply(np.log)  # Get the log of the data
df_new['log_transformed_int'].hist(figsize = (6,6),bins=20)
```


```python
df_new['log_transformed_gg'] = (df['Gender gap index']+1).apply(np.log)  # Get the log of the data
df_new['log_transformed_gg'].hist(figsize = (6,6),bins=20)
```


```python
df_new['log_transformed_gdp_n'] = (df['gdp_nominal - US$MM']+1).apply(np.log)  # Get the log of the data
df_new['log_transformed_gdp_n'].hist(figsize = (6,6),bins=20)
```


```python
x = df_new[['log_transformed_int','log_transformed_pop','log_transformed_gdp_n','host_n','log_transformed_gg']].values
y = df_new.iloc[:,-1].values
```


```python
X_train_new,X_test_new,y_train_new,y_test_new = train_test_split(x,y,test_size = 0.2, random_state = 0)
```


```python
import statsmodels.api as sm
X_train_new = sm.add_constant(X_train_new) 

```


```python
null_counts = df_new.isnull().sum()
null_counts[null_counts > 0].sort_values
```


```python
#Treating Missing Values
df_new['log_transformed_gdp_n'].fillna(df_new['log_transformed_gdp_n'].median(), inplace=True)
```


```python
X_test_new = sm.add_constant(X_test_new) 
```


```python
result = sm.OLS(y_train_new,X_train_new).fit()
result.summary()
```


```python

```


```python

```


```python

```
